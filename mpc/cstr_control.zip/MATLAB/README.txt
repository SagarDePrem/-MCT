Run main.m from the MATLAB console to see the results.  This script runs the APM web interface for a simple CSTR model and ODE15s, MATLAB's built in DAE integrator.  You must have an internet connection to run this script.

This folder implements a series of sequential solutions to solve the model in a forward-stepping method over the time horizon.