function [A,B,C,D]=modelLinearizer(t,y,u,Ts,Cc,Dc)

fun=@(Y)yrates(t,Y,u);
[J1,Q]=jacobianest(fun, y);
% J1=numeric_jacobian(fun, y);

fun=@(u)yrates(t,y,u);
[J2,R]=jacobianest(fun, u);
% J2=numeric_jacobian(fun, u);

Ac=J1;
Bc=J2;

% if flag==0
% Cc=J1(3,:);                % for case 1
% else
% Cc=J1([1 3],:);            % for case 2
% end
% 
% if flag==0
% Dc=J2(3,:);                % for case 1
% else
% Dc=J2([1 3],:);            % for case 2
% end

sys=ss(Ac,Bc,Cc,Dc);
sys= c2d(sys,Ts);
[A, B, C, D] = ssdata(sys);

end