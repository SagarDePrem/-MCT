# numerical-jacobian

This is to calculate Jacobian of a function numerically.
See: http://www.maths.lth.se/na/courses/FMN081/FMN081-06/lecture7.pdf
